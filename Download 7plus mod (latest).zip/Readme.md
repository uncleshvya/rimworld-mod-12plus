# rimworld-mod-7plus

For English, scroll below.

Простой xml-мод, отключает самые жёсткие аспекты, чтобы дети от 7 лет тоже могли играть в Rimworld.
Инструкция по установке: папки "7plus" и "18plus" скопировать в папку "Mods", а содержимое папки "2Core" переместить в папку "Mods\Core" с перезаписью файлов.
Проверен на Римворлде v.1.0.2282 rev.722.

Simple xml mod turns off the most hardcore aspects in order to allow 7+ aged children play Rimworld.
How to install: folders "7plus" and "18plus" copy into "Mods" folder, and all from "2Core" move to "Mods\Core" folder, replace.
Tested with Rimworld v.1.0.2282 rev.722.
